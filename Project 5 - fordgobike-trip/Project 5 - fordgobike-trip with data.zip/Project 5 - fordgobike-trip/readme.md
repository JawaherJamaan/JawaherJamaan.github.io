# (Ford Go Bike 2019)
## by (Jawaher Alzahrani)


## Ford Go Bike Dataset

> This project analyzes the distribution of trips of the bike-sharing system Ford Go Bike, in the San Francisco Bay Area, taken from June through December of 2019 (total of 183412 observations).
Here make some changes in dataset for better results in data analysis:

drop missing value
Separate date and time from 'start_time' and 'end_time'
Erroneous datatypes for 'bike_id' and 'start_station_id'to object
change datatypes for 'user_type' to category
calculate age member from 'Member_Year_of_Birth'


## Summary of Findings

> I find that customers type have the lowest percentage of subscribers type for both gender.And subscribers type were more men than women.
And there is no significant difference the relationship between age and gender for bike riders , as the average age of females is 33 and men are 34 years . 
Also, there is no positive or negative relationship and we don’t any relationship between the duration trip (minute) and the members ages.
The goal of knowing the relationships so that we know what will be targeted in the future, female or male, also a customer or subscriber, and how long does a person spend on the trip.
And Through the analysis, we find that bikes rider often take between 10-20 minutes.


## Key Insights for Presentation

> What the most using of biking men or women ?
What is the average age of biking rider?
Dose duration trip effected by gender and age?
Does User Type (Subscriber or Customer) affect the duration?
What are the preferred days for gender and users type ?